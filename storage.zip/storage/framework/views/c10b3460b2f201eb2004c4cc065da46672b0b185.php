<?php $__env->startSection('body'); ?>

    <div class="card">
        <p>Hi <?php echo e($user->name); ?></p>
        <p>
            Thank you for signing up! We need to verify your email address is correct.
            Please <a href="">click this link</a> to login and verify.
        </p>

        <p>Thank You,</p>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('mail.layout', ['exclude_footer' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/intlumin/public_html/hire/resources/views/mail/user/welcome.blade.php ENDPATH**/ ?>