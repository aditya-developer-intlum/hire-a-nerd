<!-- Begin : Header  -->
<header class="_header">
    <!-- Begin: Header Top -->
    <section class="_topHeader">
        <div class="container _topHeadeCont _aj-center">
            <!-- Begin : Div --->
            <div class="_topHeader-left">
                <!-- logo -->
                <div class="logo"><a class="navbar-brand" href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset("public/storage/images/logo.png")); ?>" alt=""></a></div>
                <ul  class="_hdrInfo _inlineList">
                    <li><a href="#">How it Works</a></li>                    
                    <li><a href="#">Hire a Nerd Pro</a></li>
                    <li><a href="<?php echo e(route("become.seller")); ?>">Become a Seller</a></li>
                </ul>
            </div>
            <!-- End : Div --->
            <!-- Begin : Div --->
            <div class="_topHeader-right">
                <div class="_searchDiv">
                    <form action="">
                        <input type="text" class="form-control" placeholder="Search">
                        <button class="_subBtn btn">Search</button>
                    </form>
                </div>
              <?php if(!Auth::check()): ?>  
                <ul class="_hdrUserLink _inlineList">
                    <li class="_login"><a href="#" data-toggle="modal" data-target="#loginModal">Login</a></li>     
                    <li>or</li>               
                    <li class="_signup"><a href="#" data-toggle="modal" data-target="#signupModal">Signup</a></li>                        
                </ul>
                <?php else: ?> 
                  <ul class="_hdrUserLink _inlineList">
                        <li class="_user _active"><a href="<?php echo e(route("front.account")); ?>" class="_icon" ><?php echo e(Auth::user()->name[0]); ?></a></li>
                     <li class="_login"><a href="javascript:;" onclick="document.getElementById('logout').submit()">Logout</a></li>    

                        <form action="<?php echo e(route("logout")); ?>" method="post" id="logout">
                            <?php echo csrf_field(); ?>    
                        </form>                                       
                    </ul>
                <?php endif; ?>
            </div>
            <!-- End : Div --->
        </div>            
    </section>
    <!-- End: Header Top -->
    <!-- Begin: Header Bottom -->
    <section class="_btmHeader">
        <div class="container">
            <nav class="navbar navbar-expand-lg">                    
                <!-- nav section -->
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample05" aria-controls="navbarsExample05" aria-expanded="false" aria-label="Toggle navigation">
                    <div class="navbar-toggler-icon">
                        <div class="bar bar-1"></div>
                        <div class="bar bar-1"></div>
                        <div class="bar bar-1"></div>
                    </div>
                </button>

                
                    <div class="collapse navbar-collapse" id="navbarsExample05">
                        <ul class="navbar-nav">
                            <li class="current-menu-item menu-item-has-children">
                                <a href="<?php echo e(url("graphic-design")); ?>">Graphics & Design</a>
                                <span class="clickD"></span>
                                <ul class="sub-menu">
                            <?php $__currentLoopData = Nerd::subMenu("graphic-design"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <?php $__currentLoopData = $subMenu->subMenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <li><a href="<?php echo e(url($subMenu->slug."/".$sub->slug)); ?>"><?php echo e($sub->name); ?></a></li>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  
                                </ul>
                            </li>
                            <li class="menu-item-has-children">
                                <a href="<?php echo e(url("digital-market")); ?>">Digital Marketing</a>

                                 <span class="clickD"></span>
                                <ul class="sub-menu">
                            <?php $__currentLoopData = Nerd::subMenu("digital-market"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <?php $__currentLoopData = $subMenu->subMenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <li><a href="<?php echo e(url($subMenu->slug."/".$sub->slug)); ?>"><?php echo e($sub->name); ?></a></li>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  
                                </ul>
                                
                            </li>
                            <li class="menu-item-has-children">
                                <a href="<?php echo e(url("writing-translation")); ?>">Writing & Translation</a>
                                  <span class="clickD"></span>
                                <ul class="sub-menu">
                            <?php $__currentLoopData = Nerd::subMenu("writing-translation"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <?php $__currentLoopData = $subMenu->subMenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <li><a href="<?php echo e(url($subMenu->slug."/".$sub->slug)); ?>"><?php echo e($sub->name); ?></a></li>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  
                                </ul>
                            </li>
                            <li class="menu-item-has-children">
                                <a href="<?php echo e(url("video-animation")); ?>">Video & Animation </a>
                                 <ul class="sub-menu">
                            <?php $__currentLoopData = Nerd::subMenu("video-animation"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <?php $__currentLoopData = $subMenu->subMenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <li><a href="<?php echo e(url($subMenu->slug."/".$sub->slug)); ?>"><?php echo e($sub->name); ?></a></li>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  
                                </ul>
                            </li>
                            <li class="menu-item-has-children">
                                <a href="<?php echo e(url("music-audio")); ?>">Music & Audio  </a>
                                 <ul class="sub-menu">
                            <?php $__currentLoopData = Nerd::subMenu("music-audio"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <?php $__currentLoopData = $subMenu->subMenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <li><a href="<?php echo e(url($subMenu->slug."/".$sub->slug)); ?>"><?php echo e($sub->name); ?></a></li>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  
                                </ul>
                            </li>
                            <li class="menu-item-has-children">
                                <a href="<?php echo e(url("programming-tech")); ?>">Programming & Tech</a>
                                 <ul class="sub-menu">
                            <?php $__currentLoopData = Nerd::subMenu("programming-tech"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <?php $__currentLoopData = $subMenu->subMenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <li><a href="<?php echo e(url($subMenu->slug."/".$sub->slug)); ?>"><?php echo e($sub->name); ?></a></li>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  
                                </ul>
                            </li>
                            <li class="menu-item-has-children">
                                <a href="<?php echo e(url("business")); ?>">Business </a>
                                 <ul class="sub-menu">
                            <?php $__currentLoopData = Nerd::subMenu("business"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <?php $__currentLoopData = $subMenu->subMenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <li><a href="<?php echo e(url($subMenu->slug."/".$sub->slug)); ?>"><?php echo e($sub->name); ?></a></li>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  
                                </ul>
                            </li>
                            <li class="menu-item-has-children">  
                                <a href="<?php echo e(url("lifestyle")); ?>">Lifestyle</a>
                                 <ul class="sub-menu">
                            <?php $__currentLoopData = Nerd::subMenu("lifestyle"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <?php $__currentLoopData = $subMenu->subMenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <li><a href="<?php echo e(url($subMenu->slug."/".$sub->slug)); ?>"><?php echo e($sub->name); ?></a></li>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  
                                </ul>
                            </li>                                                         
                        </ul>
                    </div>
            </nav>
        </div>
    </section>
    <!-- End: Header Bottom -->       
</header>
<!-- End : Header ---><?php /**PATH /var/www/html/hire-a-nerd/resources/views/layouts/header-before-login.blade.php ENDPATH**/ ?>