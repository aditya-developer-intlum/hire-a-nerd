<?php $__env->startSection('content'); ?>


<main class="main_body _dBody _grayBg">
        <div class="container">
            <div class="row _dRow">
               
                <!-- Right page -->
                <div class="col-md-7">
                    
                   <div class="_dCard">
                                <div class="_dCardHeader _borderBtm">                            
                                    <span class="_dHeading ">Post Request</span> 
                                </div>                        
                                <div class="_dsBody">
                                    <form action="<?php echo e(route('post-request.store')); ?>" method="post" enctype="multipart/form-data" class="_dForm">
                                    	<?php echo csrf_field(); ?>
                                    	
                                        <div class="form-group row">
                                            <div class="col-md-4"><label class="_label" style="height:70%" for="">Describe the service you're looking to purchase - please be as detailed as possible: </label></div>
                                            <div class="col-md-8">
                                          
                                          <textarea name="description" class="form-control2" cols="30" rows="10" placeholder="I'm looking for..." maxlength="2500"><?php echo e(old('description')); ?></textarea>
                                          <span class="text-danger" >
											 <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?>
											 	<?php echo e($message); ?>

											 <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                          </span><br>
                                          <button class="btn btn-primary" type="button" onclick="document.getElementById('attachFile').click()"><i class="fa fa-paperclip" aria-hidden="true"></i> Attach File</button>
                                          
                                          <input type="file" name="attachfile" style="display: none" id="attachFile"> 


                                          <span class="text-danger" >
											 <?php if ($errors->has('attachfile')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('attachfile'); ?>
											 	<?php echo e($message); ?>

											 <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                          </span>
                                      </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-md-4"><label class="_label" style="height:70%" for="">Category  :</label></div>
                                            <div class="col-md-8">
                                            	<select name="category" id="category" class="form-control2">
                                            		<option value="">Select Category</option>
                                            		<?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            			<option value="<?php echo e($_category->id); ?>" <?php echo e(old('category') == $_category->id ?'selected':''); ?>><?php echo e($_category->name ?? ''); ?></option>
                                            		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            	</select>
                                            	<span class="text-danger" >
											 <?php if ($errors->has('category')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('category'); ?>
											 	<?php echo e($message); ?>

											 <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                          </span>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-md-4"><label class="_label" style="height:70%" for="">Sub Category :</label></div>
                                            <div class="col-md-8">
                                            	<select name="subcategory" id="subCategory" class="form-control2">
                                            		<option value="">Select Sub Category</option>
                                            		
                                            	</select>
                                            	<span class="text-danger" >
											 <?php if ($errors->has('subcategory')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('subcategory'); ?>
											 	<?php echo e($message); ?>

											 <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                          </span>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-md-4"><label class="_label" style="height:70%" for="">When would you like your service delivered?: </label></div>
                                            <div class="col-md-8" id="timeSlot">
                                            	<select name="serviceDeliverTime" id="serviceDeliverTime" class="form-control2">
                                            		<option value="">Select Time Slot</option>
                                            		<option value="1" <?php echo e(old('serviceDeliverTime')=='1'?'selected':''); ?>>1 Day</option>
                                            		<option value="3" <?php echo e(old('serviceDeliverTime')=='3'?'selected':''); ?>>3 Days</option>
                                            		<option value="7" <?php echo e(old('serviceDeliverTime')=='7'?'selected':''); ?>>7 Days</option>
                                            		<option value="other" <?php echo e(old('serviceDeliverTime')=='other'?'selected':''); ?>>Other</option>
                                            		
                                            	</select>
                                            	
                                            	<span class="text-danger" >
											 <?php if ($errors->has('serviceDeliverTime')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('serviceDeliverTime'); ?>
											 	<?php echo e($message); ?>

											 <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                          </span>
                                            </div>
                                           
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-md-4"><label class="_label" style="height:70%" for="">What is your budget for this service?</label></div>
                                            <div class="col-md-8" >
                                            	<input type="text" id="budget" class="form-control2" placeholder="Enter Budget in USD" name="budget" value="<?php echo e(old('budget')); ?>">
                                            	
                                            	<span class="text-danger" >
											 <?php if ($errors->has('budget')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('budget'); ?>
											 	<?php echo e($message); ?>

											 <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                          </span>
                                            </div>
                                           
                                        </div>
                                        
                                        <div class="form-group">
                                        	
                                        	<button type="submit" class="btn _btn2 _btnSuccess"><strong>Post</strong></button>
                                            
                                        </div>
                                    </form>
                                </div>
                            </div>
                    
                </div>
                <!-- Right page -->
            </div>
        </div>        
    </main>
    <script>
    	$(document).ready(function(){

    		$("#category").change(function(){
    			var subCategory = <?php echo json_encode($subCategory, 15, 512) ?>;
    			$("#subCategory").empty().append(`<option value="">Select Sub Category</option>`);

    			$.each(subCategory,(index, val) => {
    				if(val.menu_id == this.value){
    					selected = "<?php echo e(old('subcategory')); ?>" == val.id ?"selected":''
    					$("#subCategory").append(`<option value="${val.id}" ${selected}>${val.name}</option>}
    				 option`);
    				}
    				 
    			});
    		}).change();
    		$("#serviceDeliverTime").change(function(){
    			if(this.value == 'other'){
    				$("#timeSlot")
    				.removeClass('col-md-8')
    				.addClass('col-md-4')
    				.after(` <div class="col-md-4" id="otherBox">
                                                <input type="text" name="serviceDeliverTimeOther" id="otherInput" class="form-control2" placeholder="1-30 days" value="<?php echo e(old('serviceDeliverTimeOther')); ?>">
                                            </div>`);
    			}else{
    				$("#timeSlot")
    				.removeClass('col-md-4')
    				.addClass('col-md-8');
    				$("#otherBox").remove();
    			}
	    		$("#otherInput").keypress(function(event) {
	    			var keyCode = event.keyCode;
	    			if(keyCode>48 && keyCode<57){
	    				return true;
	    			}else{
	    				return false;
	    			}
	    		});
    		}).change();
    		$("#budget").keypress(function(event) {
	    			var keyCode = event.keyCode;
	    			if(keyCode>48 && keyCode<57){
	    				return true;
	    			}else{
	    				return false;
	    			}
	    		});
    	});
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/intlumin/public_html/hire/resources/views/front/post-request.blade.php ENDPATH**/ ?>