 <!--  CSS -->
<link rel="stylesheet" href="<?php echo e(asset("public/storage/css/bootstrap.css")); ?>">	
<link rel="stylesheet" href="<?php echo e(asset("public/storage/css/animate.min.css")); ?>">
<link rel="stylesheet" href="<?php echo e(asset("public/storage/css/owl.carousel.min.css")); ?>">
<link rel="stylesheet" href="<?php echo e(asset("public/storage/css/slick.css")); ?>">
<link rel="stylesheet" href="<?php echo e(asset("public/storage/css/slick-theme.css")); ?>">
<link rel="stylesheet" href="<?php echo e(asset("public/storage/css/style.css")); ?>">
<link rel="stylesheet" href="<?php echo e(asset("public/storage/css/responsive.css")); ?>">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">

<link rel="stylesheet" type="text/css" href="<?php echo e(asset("public/css/tag.css")); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset("public/css/bootstrap-datetimepicker.min.css")); ?>">
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
<meta name="google-site-verification" content="I80YkmJ_PxYuMmhOscMp2kDh2o8H1C64vm-IIW--hh8" />

<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

  <script>
	  $( function() {
		    $( "#addFaq" ).sortable();
		    $( "#addFaq" ).disableSelection();
	  } );
  </script><?php /**PATH /home/intlumin/public_html/hire/resources/views/layouts/header-links.blade.php ENDPATH**/ ?>