<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Hire A Nerd <?php echo $__env->yieldContent("title"); ?></title>
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset("public/storage/images/favicon.png")); ?>">
    <!--  CSS -->
    

    <?php echo $__env->make("layouts.header-links", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>

    <!-- Begin : Header  -->


<?php if(Auth::check()): ?>
  
    <?php if(Auth::user()->mode == 2): ?>

        <?php echo $__env->make("layouts.seller-header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php else: ?>

        <?php echo $__env->make("layouts.header-after-login", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

<?php else: ?>
    <?php echo $__env->make("layouts.header-before-login", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
    <!-- End : Header --->

    <?php echo $__env->yieldContent("content"); ?>


    <!--- Begin:  Footer --->
    
    <?php echo $__env->make("layouts.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH /home/intlumin/public_html/hire/resources/views/layouts/app.blade.php ENDPATH**/ ?>