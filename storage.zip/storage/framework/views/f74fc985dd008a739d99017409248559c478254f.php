  <?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('contents'); ?>
 <base href="<?php echo e(asset('public/storage/admin/')); ?>/">
            <!-- begin:: Content -->
            <div class="kt-content  kt-grid__item kt-grid__item--fluid" id="kt_content">

              <!--Begin::Dashboard 1-->

           

              <!--Begin::Section-->
              <div class="row">
                <!-- <div class="col-xl-8">
                
                  begin:: Widgets/Best Sellers
                  <div class="kt-portlet kt-portlet--height-fluid">
                    <div class="kt-portlet__head">
                      <div class="kt-portlet__head-label">
                        <h3 class="kt-portlet__head-title">
                          Best Sellers
                        </h3>
                      </div>
                      <div class="kt-portlet__head-toolbar">
                        <ul class="nav nav-pills nav-pills-sm nav-pills-label nav-pills-bold" role="tablist">
                          <li class="nav-item">
                            <a class="nav-link active" data-toggle="tab" href="#kt_widget5_tab1_content" role="tab">
                              Latest
                            </a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" data-toggle="tab" href="#kt_widget5_tab2_content" role="tab">
                              Month
                            </a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" data-toggle="tab" href="#kt_widget5_tab3_content" role="tab">
                              All time
                            </a>
                          </li>
                        </ul>
                      </div>
                    </div>
                    <div class="kt-portlet__body">
                      <div class="tab-content">
                        <div class="tab-pane active" id="kt_widget5_tab1_content" aria-expanded="true">
                          <div class="kt-widget5">
                            <div class="kt-widget5__item">
                              <div class="kt-widget5__content">
                                <div class="kt-widget5__pic">
                                  <img class="kt-widget7__img" src="./assets/media//products/product27.jpg" alt="">
                                </div>
                                <div class="kt-widget5__section">
                                  <a href="#" class="kt-widget5__title">
                                    Great Logo Designn
                                  </a>
                                  <p class="kt-widget5__desc">
                                    Metronic admin themes.
                                  </p>
                                  <div class="kt-widget5__info">
                                    <span>Author:</span>
                                    <span class="kt-font-info">Keenthemes</span>
                                    <span>Released:</span>
                                    <span class="kt-font-info">23.08.17</span>
                                  </div>
                                </div>
                              </div>
                              <div class="kt-widget5__content">
                                <div class="kt-widget5__stats">
                                  <span class="kt-widget5__number">19,200</span>
                                  <span class="kt-widget5__sales">sales</span>
                                </div>
                                <div class="kt-widget5__stats">
                                  <span class="kt-widget5__number">1046</span>
                                  <span class="kt-widget5__votes">votes</span>
                                </div>
                              </div>
                            </div>
                            <div class="kt-widget5__item">
                              <div class="kt-widget5__content">
                                <div class="kt-widget5__pic">
                                  <img class="kt-widget7__img" src="./assets/media//products/product22.jpg" alt="">
                                </div>
                                <div class="kt-widget5__section">
                                  <a href="#" class="kt-widget5__title">
                                    Branding Mockup
                                  </a>
                                  <p class="kt-widget5__desc">
                                    Metronic bootstrap themes.
                                  </p>
                                  <div class="kt-widget5__info">
                                    <span>Author:</span>
                                    <span class="kt-font-info">Fly themes</span>
                                    <span>Released:</span>
                                    <span class="kt-font-info">23.08.17</span>
                                  </div>
                                </div>
                              </div>
                              <div class="kt-widget5__content">
                                <div class="kt-widget5__stats">
                                  <span class="kt-widget5__number">24,583</span>
                                  <span class="kt-widget5__sales">sales</span>
                                </div>
                                <div class="kt-widget5__stats">
                                  <span class="kt-widget5__number">3809</span>
                                  <span class="kt-widget5__votes">votes</span>
                                </div>
                              </div>
                            </div>
                            <div class="kt-widget5__item">
                              <div class="kt-widget5__content">
                                <div class="kt-widget5__pic">
                                  <img class="kt-widget7__img" src="./assets/media//products/product15.jpg" alt="">
                                </div>
                                <div class="kt-widget5__section">
                                  <a href="#" class="kt-widget5__title">
                                    Awesome Mobile App
                                  </a>
                                  <p class="kt-widget5__desc">
                                    Metronic admin themes.Lorem Ipsum Amet
                                  </p>
                                  <div class="kt-widget5__info">
                                    <span>Author:</span>
                                    <span class="kt-font-info">Fly themes</span>
                                    <span>Released:</span>
                                    <span class="kt-font-info">23.08.17</span>
                                  </div>
                                </div>
                              </div>
                              <div class="kt-widget5__content">
                                <div class="kt-widget5__stats">
                                  <span class="kt-widget5__number">210,054</span>
                                  <span class="kt-widget5__sales">sales</span>
                                </div>
                                <div class="kt-widget5__stats">
                                  <span class="kt-widget5__number">1103</span>
                                  <span class="kt-widget5__votes">votes</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="tab-pane" id="kt_widget5_tab2_content">
                          <div class="kt-widget5">
                            <div class="kt-widget5__item">
                              <div class="kt-widget5__content">
                                <div class="kt-widget5__pic">
                                  <img class="kt-widget7__img" src="./assets/media//products/product10.jpg" alt="">
                                </div>
                                <div class="kt-widget5__section">
                                  <a href="#" class="kt-widget5__title">
                                    Branding Mockup
                                  </a>
                                  <p class="kt-widget5__desc">
                                    Metronic bootstrap themes.
                                  </p>
                                  <div class="kt-widget5__info">
                                    <span>Author:</span>
                                    <span class="kt-font-info">Fly themes</span>
                                    <span>Released:</span>
                                    <span class="kt-font-info">23.08.17</span>
                                  </div>
                                </div>
                              </div>
                              <div class="kt-widget5__content">
                                <div class="kt-widget5__stats">
                                  <span class="kt-widget5__number">24,583</span>
                                  <span class="kt-widget5__sales">sales</span>
                                </div>
                                <div class="kt-widget5__stats">
                                  <span class="kt-widget5__number">3809</span>
                                  <span class="kt-widget5__votes">votes</span>
                                </div>
                              </div>
                            </div>
                            <div class="kt-widget5__item">
                              <div class="kt-widget5__content">
                                <div class="kt-widget5__pic">
                                  <img class="kt-widget7__img" src="./assets/media//products/product11.jpg" alt="">
                                </div>
                                <div class="kt-widget5__section">
                                  <a href="#" class="kt-widget5__title">
                                    Awesome Mobile App
                                  </a>
                                  <p class="kt-widget5__desc">
                                    Metronic admin themes.Lorem Ipsum Amet
                                  </p>
                                  <div class="kt-widget5__info">
                                    <span>Author:</span>
                                    <span class="kt-font-info">Fly themes</span>
                                    <span>Released:</span>
                                    <span class="kt-font-info">23.08.17</span>
                                  </div>
                                </div>
                              </div>
                              <div class="kt-widget5__content">
                                <div class="kt-widget5__stats">
                                  <span class="kt-widget5__number">210,054</span>
                                  <span class="kt-widget5__sales">sales</span>
                                </div>
                                <div class="kt-widget5__stats">
                                  <span class="kt-widget5__number">1103</span>
                                  <span class="kt-widget5__votes">votes</span>
                                </div>
                              </div>
                            </div>
                            <div class="kt-widget5__item">
                              <div class="kt-widget5__content">
                                <div class="kt-widget5__pic">
                                  <img class="kt-widget7__img" src="./assets/media//products/product6.jpg" alt="">
                                </div>
                                <div class="kt-widget5__section">
                                  <a href="#" class="kt-widget5__title">
                                    Great Logo Designn
                                  </a>
                                  <p class="kt-widget5__desc">
                                    Metronic admin themes.
                                  </p>
                                  <div class="kt-widget5__info">
                                    <span>Author:</span>
                                    <span class="kt-font-info">Keenthemes</span>
                                    <span>Released:</span>
                                    <span class="kt-font-info">23.08.17</span>
                                  </div>
                                </div>
                              </div>
                              <div class="kt-widget5__content">
                                <div class="kt-widget5__stats">
                                  <span class="kt-widget5__number">19,200</span>
                                  <span class="kt-widget5__sales">sales</span>
                                </div>
                                <div class="kt-widget5__stats">
                                  <span class="kt-widget5__number">1046</span>
                                  <span class="kt-widget5__votes">votes</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="tab-pane" id="kt_widget5_tab3_content">
                          <div class="kt-widget5">
                            <div class="kt-widget5__item">
                              <div class="kt-widget5__content">
                                <div class="kt-widget5__pic">
                                  <img class="kt-widget7__img" src="./assets/media//products/product11.jpg" alt="">
                                </div>
                                <div class="kt-widget5__section">
                                  <a href="#" class="kt-widget5__title">
                                    Awesome Mobile App
                                  </a>
                                  <p class="kt-widget5__desc">
                                    Metronic admin themes.Lorem Ipsum Amet
                                  </p>
                                  <div class="kt-widget5__info">
                                    <span>Author:</span>
                                    <span class="kt-font-info">Fly themes</span>
                                    <span>Released:</span>
                                    <span class="kt-font-info">23.08.17</span>
                                  </div>
                                </div>
                              </div>
                              <div class="kt-widget5__content">
                                <div class="kt-widget5__stats">
                                  <span class="kt-widget5__number">210,054</span>
                                  <span class="kt-widget5__sales">sales</span>
                                </div>
                                <div class="kt-widget5__stats">
                                  <span class="kt-widget5__number">1103</span>
                                  <span class="kt-widget5__votes">votes</span>
                                </div>
                              </div>
                            </div>
                            <div class="kt-widget5__item">
                              <div class="kt-widget5__content">
                                <div class="kt-widget5__pic">
                                  <img class="kt-widget7__img" src="./assets/media//products/product6.jpg" alt="">
                                </div>
                                <div class="kt-widget5__section">
                                  <a href="#" class="kt-widget5__title">
                                    Great Logo Designn
                                  </a>
                                  <p class="kt-widget5__desc">
                                    Metronic admin themes.
                                  </p>
                                  <div class="kt-widget5__info">
                                    <span>Author:</span>
                                    <span class="kt-font-info">Keenthemes</span>
                                    <span>Released:</span>
                                    <span class="kt-font-info">23.08.17</span>
                                  </div>
                                </div>
                              </div>
                              <div class="kt-widget5__content">
                                <div class="kt-widget5__stats">
                                  <span class="kt-widget5__number">19,200</span>
                                  <span class="kt-widget5__sales">sales</span>
                                </div>
                                <div class="kt-widget5__stats">
                                  <span class="kt-widget5__number">1046</span>
                                  <span class="kt-widget5__votes">votes</span>
                                </div>
                              </div>
                            </div>
                            <div class="kt-widget5__item">
                              <div class="kt-widget5__content">
                                <div class="kt-widget5__pic">
                                  <img class="kt-widget7__img" src="./assets/media//products/product10.jpg" alt="">
                                </div>
                                <div class="kt-widget5__section">
                                  <a href="#" class="kt-widget5__title">
                                    Branding Mockup
                                  </a>
                                  <p class="kt-widget5__desc">
                                    Metronic bootstrap themes.
                                  </p>
                                  <div class="kt-widget5__info">
                                    <span>Author:</span>
                                    <span class="kt-font-info">Fly themes</span>
                                    <span>Released:</span>
                                    <span class="kt-font-info">23.08.17</span>
                                  </div>
                                </div>
                              </div>
                              <div class="kt-widget5__content">
                                <div class="kt-widget5__stats">
                                  <span class="kt-widget5__number">24,583</span>
                                  <span class="kt-widget5__sales">sales</span>
                                </div>
                                <div class="kt-widget5__stats">
                                  <span class="kt-widget5__number">3809</span>
                                  <span class="kt-widget5__votes">votes</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                
                  end:: Widgets/Best Sellers
                </div> -->
                <div class="col-xl-12">

                  <!--begin:: Widgets/New Users-->
                  <div class="kt-portlet kt-portlet--tabs kt-portlet--height-fluid">
                    <div class="kt-portlet__head">
                      <div class="kt-portlet__head-label">
                        <h3 class="kt-portlet__head-title">
                          New Users
                        </h3>
                      </div>
                      <!-- <div class="kt-portlet__head-toolbar">
                        <ul class="nav nav-tabs nav-tabs-line nav-tabs-bold nav-tabs-line-brand" role="tablist">
                          <li class="nav-item">
                            <a class="nav-link active" data-toggle="tab" href="#kt_widget4_tab1_content" role="tab">
                              Today
                            </a>
                          </li>
                         
                        </ul>
                      </div> -->
                    </div>
                    <div class="kt-portlet__body">
                      <div class="tab-content">
                        <div class="tab-pane active" id="kt_widget4_tab1_content">
                          <div class="kt-widget4">
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="kt-widget4__item">
                              <div class="kt-widget4__pic kt-widget4__pic--pic">
                                <?php
                                  $img = 'public/storage/'.$user->userDetail->avatar
                                ?>
                                <img src="<?php echo e(asset($img)); ?>" alt="">
                              </div>
                              <div class="kt-widget4__info">
                                <a href="#" class="kt-widget4__username">
                                  <?php echo e($user->name); ?>

                                </a>
                                <!-- <p class="kt-widget4__text">
                                  Visual Designer,Google Inc
                                </p> -->
                              </div>
                            <a href=""><?php echo e(date('d M Y',strtotime($user->created_at))); ?></a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            
                            
                            
                            
                          </div>
                        </div>
                        
                      </div>
                    </div>
                  </div>

                  <!--end:: Widgets/New Users-->
                </div>
              </div>

              <!--End::Section-->

              <!--Begin::Section-->
              <!-- <div class="row">
                <div class="col-xl-4">
              
                  begin:: Widgets/Daily Sales
                  <div class="kt-portlet kt-portlet--height-fluid">
                    <div class="kt-widget14">
                      <div class="kt-widget14__header kt-margin-b-30">
                        <h3 class="kt-widget14__title">
                          Daily Sales
                        </h3>
                        <span class="kt-widget14__desc">
                          Check out each collumn for more details
                        </span>
                      </div>
                      <div class="kt-widget14__chart" style="height:120px;">
                        <canvas id="kt_chart_daily_sales"></canvas>
                      </div>
                    </div>
                  </div>
              
                  end:: Widgets/Daily Sales
                </div>
                <div class="col-xl-4">
              
                  begin:: Widgets/Profit Share
                  <div class="kt-portlet kt-portlet--height-fluid">
                    <div class="kt-widget14">
                      <div class="kt-widget14__header">
                        <h3 class="kt-widget14__title">
                          Profit Share
                        </h3>
                        <span class="kt-widget14__desc">
                          Profit Share between customers
                        </span>
                      </div>
                      <div class="kt-widget14__content">
                        <div class="kt-widget14__chart">
                          <div class="kt-widget14__stat">45</div>
                          <canvas id="kt_chart_profit_share" style="height: 140px; width: 140px;"></canvas>
                        </div>
                        <div class="kt-widget14__legends">
                          <div class="kt-widget14__legend">
                            <span class="kt-widget14__bullet kt-bg-success"></span>
                            <span class="kt-widget14__stats">37% Sport Tickets</span>
                          </div>
                          <div class="kt-widget14__legend">
                            <span class="kt-widget14__bullet kt-bg-warning"></span>
                            <span class="kt-widget14__stats">47% Business Events</span>
                          </div>
                          <div class="kt-widget14__legend">
                            <span class="kt-widget14__bullet kt-bg-brand"></span>
                            <span class="kt-widget14__stats">19% Others</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
              
                  end:: Widgets/Profit Share
                </div>
                <div class="col-xl-4">
              
                  begin:: Widgets/Revenue Change
                  <div class="kt-portlet kt-portlet--height-fluid">
                    <div class="kt-widget14">
                      <div class="kt-widget14__header">
                        <h3 class="kt-widget14__title">
                          Revenue Change
                        </h3>
                        <span class="kt-widget14__desc">
                          Revenue change breakdown by cities
                        </span>
                      </div>
                      <div class="kt-widget14__content">
                        <div class="kt-widget14__chart">
                          <div id="kt_chart_revenue_change" style="height: 150px; width: 150px;"></div>
                        </div>
                        <div class="kt-widget14__legends">
                          <div class="kt-widget14__legend">
                            <span class="kt-widget14__bullet kt-bg-success"></span>
                            <span class="kt-widget14__stats">+10% New York</span>
                          </div>
                          <div class="kt-widget14__legend">
                            <span class="kt-widget14__bullet kt-bg-warning"></span>
                            <span class="kt-widget14__stats">-7% London</span>
                          </div>
                          <div class="kt-widget14__legend">
                            <span class="kt-widget14__bullet kt-bg-brand"></span>
                            <span class="kt-widget14__stats">+20% California</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
              
                  end:: Widgets/Revenue Change
                </div>
              </div> -->

              <!--End::Section-->

              <!--Begin::Section-->
              

              <!--End::Section-->

              <!--End::Dashboard 1-->
            </div>

            <!-- end:: Content -->
          </div>
        </a></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/intlumin/public_html/hire/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>