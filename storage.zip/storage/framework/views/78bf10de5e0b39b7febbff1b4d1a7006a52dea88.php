<?php $__env->startSection("content"); ?>
<section class="_grayBg _commonPadding">
        <div class="container">
            <!-- Begin: Heading -->
            <div class="_headingDiv">
                <h2 class="_headingTxt">    

              <?php echo e($title); ?></h2>               
            </div>
            <!-- End : Heading  -->
            <div class="row _infoBoxRow">
                <!-- Begin: Col -->
                <?php $__currentLoopData = $gigs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gig): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php 
                         $avatar = $gig->user->userDetail->avatar;
                    ?>
                <div class="col-lg-3 col-md-4">
                    <!-- Begin: Info Box -->
                    <div class="_infoBox__outter">
                        <div class="_infoBox__inner"> 
                         <a href="<?php echo e(url($gig->menu->slug.'/'.$gig->subMenu->slug.'/'.$gig->id)); ?>" style="color: white">    
                            <figure class="_infoBox__img">
                              <img src="<?php echo e(asset("public/storage/$gig->gig_photo_one")); ?>" alt="">
                            </figure> 
                        </a>
                            <div class="_infoBox__desc _bgWhite">
                                <div class="_infoBox__desc1">
                                    <div class="_about">
                                        <div class="_aboutSeller">
                                            <figure class="_proImg"><img src="<?php echo e(url("public/storage/$avatar")); ?>" alt=""></figure>
                                            <div class="_proInfo">
                                                <span class="_proName"><?php echo e($gig->user->name); ?></span>
                                                <span class="_proCat">4 Star Seller</span>
                                            </div>
                                        </div>
                                        <div class="_feedSec">
                                            <span class="_likeBtn _liked"><i class="far fa-heart" data-service='<?php echo e($gig->id); ?>'></i></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="_infoBox__desc2">
                                     <a href="<?php echo e(url($gig->menu->slug.'/'.$gig->subMenu->slug.'/'.$gig->id)); ?>" style="color: white"> 
                                    <p><?php echo e(title_case($gig->gig_title)); ?></p>
                                </a>
                                </div>
                            </div>
                            <div class="_extraInfo">
                                <div class="_ratingInfo"><span><i class="fas fa-star"></i> 4.0</span>Rating 4.0 (251)</div>
                                <div class="_startInfo">Starting at <span>$<?php echo e($gig->gigPrice->basic_price ?? 0); ?></span></div>
                            </div>       
                        </div>
                        <!-- Begin:  overlay -->
                        <div class="_infoBox__overlay">
                            <div class="_content">
                                <p class="_cHeading"><?php echo e($gig->subMenu->name); ?></p>
                                <p class="_cInfo"><?php echo e($gig->describe_detail_offer); ?></p>
                                   <a href="<?php echo e(url($gig->menu->slug.'/'.$gig->subMenu->slug.'/'.$gig->id)); ?>" style="color: white"> <div class="btn _lineBtn">Find Out More</div></a>
                            </div>
                        </div>
                        <!-- End: overlay -->
                    </div>
                    <!-- End: Info Box -->
                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="row">
            	
            	<div class="col-md-2">
            		   &nbsp;
            	</div>
            		<div class="col-md-8" style="padding: 48px 0px 0px 219px;">
            		  <center><?php echo e($gigs->links()); ?></center> 
            	</div>
            		<div class="col-md-2">
            		 &nbsp;	
            	</div>
            </div>
     
        </div>

    </section>

    <script>
    $(document).ready(function(){
        $(".far").click(function(){
            var ele = $(this).data('service');

            $.post('<?php echo e(route('wishlist.store')); ?>', { _token: '<?php echo e(csrf_token()); ?>',service_id:ele });

            if($(`i[data-service = ${ele}]`).attr('class') == 'far fa-heart'){

               $(`i[data-service = ${ele}]`).removeClass('far fa-heart').addClass('fas fa-heart');
            }else{

                $(`i[data-service = ${ele}]`).removeClass('fas fa-heart fa-bounce').addClass('far fa-heart');
            }
        });

        $.each(<?php echo json_encode($wish, 15, 512) ?>, function(index, val) {

            $(`i[data-service = ${val.gig_id}]`).removeClass('far fa-heart').addClass('fas fa-heart');

        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/hire-a-nerd/resources/views/front/page.blade.php ENDPATH**/ ?>