<?php $__env->startSection("content"); ?>

<main class="main_body _dBody">
        <div class="container">
            <!-- Begin: Heading -->
            <div class="_headingDiv text-center">
                <h2 class="_headingTxt"><?php echo e($title); ?></h2>
                <p class="_headingTag">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incidi</p>
            </div>
            <!-- End : Heading  --> 
            <div class="row">
                <div class="col-md-3">
                    <section class="_category-list-div">
                    <h4><?php echo e($title); ?></h4>
                    <ul class="_category-list">
                    <?php $__currentLoopData = $sidebar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                    <?php $__currentLoopData = $subMenu->subMenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                    	<li><a href="<?php echo e(url($subMenu->slug."/".$sub->slug)); ?>"><?php echo e($sub->name); ?></a></li>
	                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>

                    </section>                    
                </div>
                <div class="col-md-9">
                    <div class="row">

            <?php $__currentLoopData = $sidebar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		        <?php $__currentLoopData = $subMenu->subMenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		            
		            <div class="col-md-4">
                        <a href="<?php echo e(url($subMenu->slug."/".$sub->slug)); ?>" class="_category-box">
                            <figure class="_cat-figure">
                                <img src="<?php echo e(asset("public/storage/images/populor-img-".rand(1,5).".jpg")); ?>" alt="img-fluid">
                            </figure>
                           	<span class="_cat-name"><?php echo e($sub->name); ?></span>
                        </a>
                    </div>
		        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      
                        
                       
                    </div>
                </div>
            </div>	

        </div>        
    </main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/hire-a-nerd/resources/views/front/category.blade.php ENDPATH**/ ?>