  <?php $__env->startSection('title','User'); ?>
<?php $__env->startSection('contents'); ?>

<div class="kt-content  kt-grid__item kt-grid__item--fluid" id="kt_content">
							<div class="row">
								<div class="col-lg-12">
										

									<!--begin::Portlet-->
									<div class="kt-portlet">
										<div class="kt-portlet__head">
											<div class="kt-portlet__head-label">
												<h3 class="kt-portlet__head-title">
													Create User
												</h3>
											</div>
										</div>
										
									

										<!--begin::Form-->
										<form class="kt-form kt-form--label-right" autocomplete="off" method="post" action="<?php echo e(route('admin.user.store')); ?>" enctype="multipart/form-data">
											<?php echo csrf_field(); ?>
											<div class="kt-portlet__body">
												<div class="form-group row">
													<div class="col-lg-6">
														<label for='first_name'>First Name:</label>
														<input type="text" class="form-control" placeholder="Enter first name" name="first_name" value="<?php echo e(old('first_name')); ?>" autocomplete="off" maxlength="125">
														<?php if ($errors->has('first_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('first_name'); ?>
															<span class="text-danger"><?php echo e($message); ?></span>
														<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
													</div>
													<div class="col-lg-6">
														<label for="last_name">Last Name:</label>
														<input type="text" class="form-control" placeholder="Enter last name" name="last_name" value="<?php echo e(old('last_name')); ?>" autocomplete="off" maxlength="125">
														<?php if ($errors->has('last_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('last_name'); ?>
															<span class="text-danger"><?php echo e($message); ?></span>
														<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
													</div>
												</div>

												<div class="form-group row">
													<div class="col-lg-6">
														<label for='email'>Email Id:</label>
														<input type="email" class="form-control" placeholder="Enter email id" name="email" value="<?php echo e(old('email')); ?>" autocomplete="off" maxlength="255">
														<?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
															<span class="text-danger"><?php echo e($message); ?></span>
														<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
													</div>
													<div class="col-lg-6">
														<label for="mobile_number">Contact Number:</label>
														<input type="text" class="form-control" placeholder="Enter contact number" name="mobile_number" value="<?php echo e(old('mobile_number')); ?>" autocomplete="off" maxlength="12">
														<?php if ($errors->has('mobile_number')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('mobile_number'); ?>
															<span class="text-danger"><?php echo e($message); ?></span>
														<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
													</div>
												</div>

												<div class="form-group row">
													<div class="col-lg-6">
														
												
														<label for='address'>Address:</label>
														<textarea name="address"  class="form-control" rows="3" maxlength="500"><?php echo e(old('address')); ?></textarea>
											
														<?php if ($errors->has('address')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('address'); ?>
															<span class="text-danger"><?php echo e($message); ?></span>
														<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
													</div>
													<div class="col-lg-6">
														<label for="country">Country:</label>
														<select name="country" class="form-control">
															<option value="">Select Country</option>
															<?php $__currentLoopData = $country->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $_country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
															<option value="<?php echo e($_country->name); ?>" <?php echo e($_country->name==old('country') ?'selected':''); ?>><?php echo e($_country->name); ?></option>
															<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
														</select>
														<?php if ($errors->has('country')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('country'); ?>
															<span class="text-danger"><?php echo e($message); ?></span>
														<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
													</div>
												</div>
												<div class="form-group row">
													<div class="col-lg-6">
														
												
														<label for='customFile'>Avatar:</label>
													<div class="custom-file">
														<input type="file" class="custom-file-input" id="customFile" name="avatar" accept="image/*">
														<label class="custom-file-label" for="customFile">Choose file</label>
													</div>
														
											
														<?php if ($errors->has('avatar')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('avatar'); ?>
															<span class="text-danger"><?php echo e($message); ?></span>
														<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
													</div>
													<div class="col-lg-6">
														<label for="mobile_number">Password:</label>
														<input type="text" name="password" class="form-control" value="<?php echo e(old('password')); ?>" maxlength="30">
														<?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
															<span class="text-danger"><?php echo e($message); ?></span>
														<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
													</div>
												</div>
												
												
											</div>
											<div class="kt-portlet__foot">
												<div class="kt-form__actions">
													<div class="row">
														<div class="col-lg-6">
															<button type="submit" class="btn btn-primary">Save</button>
															<button type="reset" class="btn btn-secondary">Cancel</button>
														</div>
														<div class="col-lg-6 kt-align-right">
															<a  href='<?php echo e(route('admin.user.index')); ?>' class="btn btn-danger">Back</a>
														</div>
													</div>
												</div>
											</div>
										</form>

										<!--end::Form-->
									</div>

									<!--end::Portlet-->

								</div>
							</div>
						</div>

<?php $__env->startPush('scripts'); ?>
    <script >
<?php if(Session::has('success')): ?>
			Swal.fire({
			  type: 'success',
			  title: '<?php echo e(Session::get('success')); ?>',
			});
<?php endif; ?>
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/hire-a-nerd/resources/views/admin/user/create.blade.php ENDPATH**/ ?>