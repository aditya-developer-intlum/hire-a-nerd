  <?php $__env->startSection('title','User'); ?>
<?php $__env->startSection('contents'); ?>

<div class="kt-content  kt-grid__item kt-grid__item--fluid" id="kt_content">
							<div class="row">
								<div class="col-lg-12">
										

									<!--begin::Portlet-->
									<div class="kt-portlet">
										<div class="kt-portlet__head">
											<div class="kt-portlet__head-label">
												<h3 class="kt-portlet__head-title">
													Edit Sub Admin
												</h3>
											</div>
										</div>
										
									

										<!--begin::Form-->
<form class="kt-form kt-form--label-right" autocomplete="off" method="post" 
action="<?php echo e(route('admin.sub-admin.update',[$user->id])); ?>">
<?php echo method_field('PUT'); ?>
<?php echo csrf_field(); ?>

<div class="kt-portlet__body">
	<div class="form-group row">
		<div class="col-lg-6">
			<label for='first_name'>First Name:</label>
			<input type="text" class="form-control" placeholder="Enter first name" 
			name="first_name" value="<?php echo e($user->f_name ?? ''); ?>" autocomplete="off"
			 maxlength="125">
			<?php if ($errors->has('first_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('first_name'); ?>
				<span class="text-danger"><?php echo e($message); ?></span>
			<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
		</div>
		<div class="col-lg-6">
			<label for='last_name'>Last Name:</label>
			<input type="text" class="form-control" placeholder="Enter last name" 
			name="last_name" value="<?php echo e($user->l_name ?? ''); ?>" autocomplete="off"
			 maxlength="125">
			<?php if ($errors->has('last_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('last_name'); ?>
				<span class="text-danger"><?php echo e($message); ?></span>
			<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
		</div>
	</div>
	<div class="form-group row">
		<div class="col-lg-6">
			<label for='email'>Email:</label>
			<input type="text" class="form-control" placeholder="Enter email " 
			name="email" value="<?php echo e($user->email ?? ''); ?>" autocomplete="off"
			 maxlength="225">
			<?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
				<span class="text-danger"><?php echo e($message); ?></span>
			<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
		</div>
		<div class="col-lg-6">
			<label for='mobile_number'>Mobile Number:</label>
			<input type="text" class="form-control" placeholder="Enter mobile number" 
			name="mobile_number" value="<?php echo e($user->mobile_number); ?>" autocomplete="off"
			 maxlength="10">
			<?php if ($errors->has('mobile_number')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('mobile_number'); ?>
				<span class="text-danger"><?php echo e($message); ?></span>
			<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
		</div>
	</div>
	

																								
</div>
											<div class="kt-portlet__foot">
												<div class="kt-form__actions">
													<div class="row">
														<div class="col-lg-6">
															<button type="submit" class="btn btn-primary">Update</button>
															<button type="reset" class="btn btn-secondary">Cancel</button>
														</div>
														<div class="col-lg-6 kt-align-right">
															<a  href='<?php echo e(route('admin.sub-admin.index')); ?>' class="btn btn-danger">Back</a>
														</div>
													</div>
												</div>
											</div>
										</form>

										<!--end::Form-->
									</div>

									<!--end::Portlet-->

								</div>
							</div>
						</div>

<?php $__env->startPush('scripts'); ?>
    <script >
<?php if(Session::has('success')): ?>
			Swal.fire({
			  type: 'success',
			  title: '<?php echo e(Session::get('success')); ?>',
			});
<?php endif; ?>
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/hire-a-nerd/resources/views/admin/sub-admin/edit.blade.php ENDPATH**/ ?>