
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<div id="app">
	
	
	<example-component :user-data="'<?php echo Auth::user()->id; ?>'"></example-component>

</div>
<script src="<?php echo e(asset('public/js/app.js')); ?>"></script>
<script>

 Echo.private('user.<?php echo e(Auth::user()->id); ?>')
          .listen('NewMessageNotification', (e) => {
              alert(e.message.name);
          });

	</script><?php /**PATH /var/www/html/hire-a-nerd/resources/views/chat.blade.php ENDPATH**/ ?>