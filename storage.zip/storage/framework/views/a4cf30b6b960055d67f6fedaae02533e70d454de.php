<?php $__env->startSection('title','| Orders'); ?>
<?php $__env->startSection('content'); ?>

	<main class="main_body _dBody _grayBg">
        <div class="container">
            <!-- Begin: Heading -->
            <div class="_headingDiv">
                <h2 class="_headingTxt">Manage Orders</h2>
            </div>
            <!-- End : Heading -->
            <div class="_dCard _p0">
                <div class="_dCardHeader _borderBtm _p0">
                    <ul class="nav nav-tabs _order-tab">
                      
                    <li><a data-toggle="tab" href="#active-tab" class="active">ACTIVE</a>
                    </li>
                   <!--  <li class="active"><a data-toggle="tab" href="#new-tab">AWAITING MY REVIEW</a>
                     
                   </li> -->
                    
                    <li><a data-toggle="tab" href="#deliverded-tab">DELIVERED</a>
                    </li>
                    <li><a data-toggle="tab" href="#completed-tab">COMPLETED</a>
                    </li>
                    <li><a data-toggle="tab" href="#canceled-tab">CANCELLED</a>
                    </li>
                    <li><a data-toggle="tab" href="#all-tab">ALL</a>
                    </li>
                    </ul>
                </div>
                <div>
                    <div class="tab-content _order-tab-content">
                     
                          <div id="active-tab" class="tab-pane fade in active show">
                            <div class="_table-div">
                                <div class="_dCardHeader">
                                    <span class="_dHeading">ACTIVE ORDERS</span>
                                </div>
                                <div class="table-responsive">
                                    <table class="table  _table">
                                        <thead>
                                        <tr>

                                            <th width="40%">SERVICE</th>
                                            <th width="15%">ORDER DATE</th>
                                            <th width="15%">DUE ON</th>
                                            <th width="15%">TOTAL</th>
                                            <th width="15%">STATUS</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $active; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            
                                            <tr>
                                               
                                                <td>
                                                   
<img src="<?php echo e(asset("public/storage/{$listing->gig->gig_photo_one }")); ?> " alt="" width="10%">
<a href="<?php echo e(url("{$listing->gig->menu->slug}/{$listing->gig->submenu->slug}/{$listing->gig->id}")); ?>" target="_blank">
    <?php echo e($listing->gig->gig_title ?? ''); ?>

</a>
    
                                                </td>
                                                <td><?php echo e(date('d M Y',strtotime($listing->created_at ?? ''))); ?></td>
                                                <td><?php echo e(date('d M Y',strtotime($listing->due_date ?? ''))); ?></td>
                                                <td>$<?php echo e($listing->total_price ?? ''); ?></td>
                                                <td>
                                                    <a href="" class="btn btn-danger">Cancel</a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr><td colspan="5">No active orders to show</td></tr>    
                                        <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        
                      
                        
                        <div id="deliverded-tab" class="tab-pane fade">
                            <div class="_table-div">
                                <div class="_dCardHeader">
                                    <span class="_dHeading">DELIVERED ORDERS</span>
                                </div>
                                <div class="table-responsive">
                                    <table class="table  _table">
                                        <thead>
                                        <tr>
                                            <th width="40%">SERVICE</th>
                                            <th width="15%">ORDER DATE</th>
                                            <th width="15%">DUE ON</th>
                                            <th width="15%">TOTAL</th>
                                            <th width="15%">STATUS</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $delivered; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                              
                                            <tr>
                                               
                                                <td>
                                                   
<img src="<?php echo e(asset("public/storage/{$listing->gig->gig_photo_one }")); ?> " alt="" width="10%">
<a href="<?php echo e(url("{$listing->gig->menu->slug}/{$listing->gig->submenu->slug}/{$listing->gig->id}")); ?>" target="_blank">
    <?php echo e($listing->gig->gig_title ?? ''); ?>

</a>
    
                                                </td>
                                                <td><?php echo e(date('d M Y',strtotime($listing->created_at ?? ''))); ?></td>
                                                <td><?php echo e(date('d M Y',strtotime($listing->due_date ?? ''))); ?></td>
                                                <td>$<?php echo e($listing->total_price ?? ''); ?></td>
                                                <td>
                                                    <a href="" class="btn btn-primary">Review</a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                        <tr><td colspan="5">No delivered orders to show</td></tr>    
                                        <?php endif; ?>   
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div id="completed-tab" class="tab-pane fade">
                            <div class="_table-div">
                                <div class="_dCardHeader">
                                    <span class="_dHeading">COMPLETED ORDERS</span>
                                </div>
                                <div class="table-responsive">
                                    <table class="table  _table">
                                        <thead>
                                        <tr>
                                            <th width="40%">SERVICE</th>
                                            <th width="15%">ORDER DATE</th>
                                            <th width="15%">DUE ON</th>
                                            <th width="15%">TOTAL</th>
                                            <th width="15%">STATUS</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__empty_1 = true; $__currentLoopData = $completed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                               
                                                <td>
                                                   
<img src="<?php echo e(asset("public/storage/{$listing->gig->gig_photo_one }")); ?> " alt="" width="10%">
<a href="<?php echo e(url("{$listing->gig->menu->slug}/{$listing->gig->submenu->slug}/{$listing->gig->id}")); ?>" target="_blank">
    <?php echo e($listing->gig->gig_title ?? ''); ?>

</a>
    
                                                </td>
                                                <td><?php echo e(date('d M Y',strtotime($listing->created_at ?? ''))); ?></td>
                                                <td><?php echo e(date('d M Y',strtotime($listing->due_date ?? ''))); ?></td>
                                                <td>$<?php echo e($listing->total_price ?? ''); ?></td>
                                                <td>
                                                    <a href="" class="btn btn-success">Order Again</a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr><td colspan="5">No completed orders to show</td></tr>    
                                        <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div id="canceled-tab" class="tab-pane fade">
                            <div class="_table-div">
                                <div class="_dCardHeader">
                                    <span class="_dHeading">CANCELLED ORDERS</span>
                                </div>
                                <div class="table-responsive">
                                    <table class="table  _table">
                                        <thead>
                                        <tr>
                                            <th width="40%">SERVICE</th>
                                            <th width="15%">ORDER DATE</th>
                                            <th width="15%">DUE ON</th>
                                            <th width="15%">TOTAL</th>
                                            <th width="15%">STATUS</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__empty_1 = true; $__currentLoopData = $cancelled; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                
                                            <tr>
                                               
                                                <td>
                                                   
<img src="<?php echo e(asset("public/storage/{$listing->gig->gig_photo_one }")); ?> " alt="" width="10%">
<a href="<?php echo e(url("{$listing->gig->menu->slug}/{$listing->gig->submenu->slug}/{$listing->gig->id}")); ?>" target="_blank">
    <?php echo e($listing->gig->gig_title ?? ''); ?>

</a>
    
                                                </td>
                                                <td><?php echo e(date('d M Y',strtotime($listing->created_at ?? ''))); ?></td>
                                                <td><?php echo e(date('d M Y',strtotime($listing->due_date ?? ''))); ?></td>
                                                <td>$<?php echo e($listing->total_price ?? ''); ?></td>
                                                <td>
                                                    <a href="" class="btn btn-success">Order Again</a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                             <tr><td colspan="5">No completed cancelled to show</td></tr>            

                                        <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div id="all-tab" class="tab-pane fade">
                            <div class="_table-div">
                                <div class="_dCardHeader">
                                    <span class="_dHeading">ALL ORDERS</span>
                                </div>
                                <div class="table-responsive">
                                    <table class="table  _table">
                                        <thead>
                                        <tr>
                                            <th width="40%">SERVICE</th>
                                            <th width="15%">ORDER DATE</th>
                                            <th width="15%">DUE ON</th>
                                            <th width="15%">TOTAL</th>
                                            <th width="15%">STATUS</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__empty_1 = true; $__currentLoopData = $all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                               
                                                <td>
                                                   
<img src="<?php echo e(asset("public/storage/{$listing->gig->gig_photo_one }")); ?> " alt="" width="10%">
<a href="<?php echo e(url("{$listing->gig->menu->slug}/{$listing->gig->submenu->slug}/{$listing->gig->id}")); ?>" target="_blank">
    <?php echo e($listing->gig->gig_title ?? ''); ?>

</a>
    
                                                </td>
                                                <td><?php echo e(date('d M Y',strtotime($listing->created_at ?? ''))); ?></td>
                                                <td><?php echo e(date('d M Y',strtotime($listing->due_date ?? ''))); ?></td>
                                                <td>$<?php echo e($listing->total_price ?? ''); ?></td>
                                                <td>
                                                    <a href="" class="btn btn-success">Order Again</a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                             <tr><td colspan="5">No orders to show</td></tr>    
                                        <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                     
                    </div>
                </div>

            </div>
        </div>
    </main>
    <script>
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/intlumin/public_html/hire/resources/views/front/order.blade.php ENDPATH**/ ?>