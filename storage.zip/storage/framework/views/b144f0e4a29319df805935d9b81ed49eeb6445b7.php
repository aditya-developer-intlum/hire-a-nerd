<!-- Begin : Header  -->
<header class="_header">
        <!-- Begin: Header Top -->
        <section class="_topHeader">
            <div class="container _topHeadeCont _aj-center">
                <!-- Begin : Div --->
                <div class="_topHeader-left">
                    <!-- logo -->
                    <div class="logo"><a class="navbar-brand" href="<?php echo e(url('/')); ?>"><img src="<?php echo e(url("public/storage/images/logo.png")); ?>" alt=""></a></div>
                    <ul  class="_hdrInfo _inlineList">                                            
                        <li><a href="<?php echo e(url('/')); ?>">Hire a Nerd Pro</a></li>
                        <li><a href="<?php echo e(route("become.seller")); ?>">Become a Seller</a></li>
                        <li><a href="<?php echo e(route('seller.message.index')); ?>">Messages</a></li>
                        <li><a href="<?php echo e(route('wishlist.index')); ?>">Saved</a></li>
                        <li><a href="<?php echo e(route('orders.index')); ?>">Orders</a></li>                        
                    </ul>
                </div>
                <!-- End : Div --->
                <!-- Begin : Div --->
                <div class="_topHeader-right">
                    <div class="_searchDiv">
                        <form action="">
                            <input type="text" class="form-control" placeholder="Find Service">
                            <button class="_subBtn btn">Search</button>
                        </form>
                    </div>
                      <ul class="_hdrUserLink _inlineList">
                        <li style='cursor:pointer' id='switch_dashboard'>
                             <div class="">
                                <a ><strong> <?php echo e(Auth::user()->mode==1?'Switch to Selling':'Switch to Buying'); ?></strong></a>
                             </div>
                          
                        </li>
                        <li class="_user _active"><a href="<?php echo e(route("front.account")); ?>" class="_icon" ><?php echo e(Auth::user()->name[0]); ?></a></li>
                     <li class="_login"><a href="#" onclick="document.getElementById('logout').submit()">Logout</a></li>    

                        <form action="<?php echo e(route("logout")); ?>" method="post" id="logout">
                            <?php echo csrf_field(); ?>    
                        </form>                                       
                    </ul>
                <!-- End : Div --->
            </div>            
        </section>
        <!-- End: Header Top -->
        <!-- Begin: Header Bottom -->
        <section class="_btmHeader _blueGradient">
            <div class="container">
                <nav class="navbar navbar-expand-lg">                    
                    <!-- nav section -->
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample05" aria-controls="navbarsExample05" aria-expanded="false" aria-label="Toggle navigation">
                        <div class="navbar-toggler-icon">
                            <div class="bar bar-1"></div>
                            <div class="bar bar-1"></div>
                            <div class="bar bar-1"></div>
                        </div>
                    </button>


                    <div class="collapse navbar-collapse" id="navbarsExample05">
                        <ul class="navbar-nav">
                            
                        <?php $__currentLoopData = Nerd::category(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                        

                            <li class="current-menu-item menu-item-has-children">
                                <a href="<?php echo e(url($category->slug)); ?>"> <?php echo e($category->name); ?> </a>
                                <span class="clickD"></span>
                                <ul class="sub-menu">
                       
                            <?php if(empty(!$category->submenu)): ?>

                                <?php $__currentLoopData = $category->submenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="<?php echo e(url($category->slug.'/'.$subcategory->slug)); ?>"><?php echo e($subcategory->name); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            <?php endif; ?>      
                                </ul>
                            </li>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                     
                        </ul>
                    </div>
                </nav>
            </div>
        </section>
        <!-- End: Header Bottom -->       
    </header>
    <!-- End : Header --->
  <?php /**PATH /var/www/html/hire-a-nerd/resources/views/layouts/header-after-login.blade.php ENDPATH**/ ?>