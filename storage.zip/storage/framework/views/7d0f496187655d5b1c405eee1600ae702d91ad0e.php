<?php $__env->startSection("content"); ?>
<div id="app">
<main class="_dashboard__page">
    <!-- Dashboard page inner begin -->
    <div class="_dashboard__wrapper">
        <!-- Row begin  -->
        <div class="_dashboard__row _flexDiv">          

            <!-- Dashboar Left section begin  -->
            <div class="_dashboard__leftSec">
                <div class="_d__body _tmeassage__body">
                    <!-- Dashboard header begin  -->
                    <section class="_d__header">
                    
                    </section>
                    <!-- Dashboard  header end   -->


                    <!-- dashboard body begin  -->
                    <section class="_d__bodyInner">
                        <section class="_d__body__wrapper container">
                            
                            <!-- row begin  -->
                            <div class="row">                                    
                                    <!-- col begin  -->
                                <div class="col-md-12 _mB__30">
                                    <div class="_dCard _msgCard">
                                        <div class="_msgOterWarp">
                                            <div class="_msgInnerWarp _flexDiv">
                                                <div class="_msgInnerWarp__lft">
                                                    <!-- Chatlist outer begin  -->
                                                    <div class="_chatOuter">
                                                        <!-- Chat header begin  -->
                                                        <!-- <div class="_chatHeader">
                                                            conv : begin
                                                            <div class=" _conv-option">
                                                                <a hter="#" class="hoverDropdown_btn _click-btn">All Conversation <i class="fas fa-caret-down"></i></a>                         
                                                                <div class="_click-box">                            
                                                                    <div class="hoverDropdown__inner">
                                                                        <div class="hoverDropdown__header">All Conversation</div> 
                                                                        <div class="hoverDropdown__body">
                                                                            <ul class="hoverDropdown_content">
                                                                                <ul>
                                                                                    <li><a href="#">Uread</a></li>
                                                                                    <li><a href="#">Starred</a></li>
                                                                                </ul>                                                
                                                                                <ul>
                                                                                    <li><a href="#">Uread</a></li>
                                                                                    <li><a href="#">Spam</a></li>
                                                                                </ul>                                                
                                                                                <ul>
                                                                                    <li><a href="#">Uread</a></li>
                                                                                    <li><a href="#">Spam</a></li>
                                                                                </ul>                                                
                                                                            </ul>
                                                                        </div>                                                                                            
                                                                    </div>                            
                                                                </div>                      
                                                            </div>
                                                            conv : end
                                                            <div class="_msg__srch">
                                                                <form class="_srcForm _flexDiv">
                                                                    <div class="_src-input-div hide" >
                                                                        <input type="text"  placeholder="Search">
                                                                        <div class="_s-close"><i class="fas fa-times"></i></div>
                                                                    </div>                                                                    
                                                                   
                                                                </form>
                                                                
                                                            </div>
                                                        </div> -->
                                                        <!-- Chat header end  -->
                                                        <!-- Chat list begin  -->
                                                        <div class="_chatListsBox ">
                                                            

                <message-component :message-data="<?php echo e(json_encode([
                                        'friends' => $friends,
                                        'asset' =>  asset('public/storage'),
                                        'readMessagePath' => route('seller.message.read'),
                                        'user' => Auth::user()
                    ])); ?>"></message-component>
                                                        </div>
                                                        <!-- Chat list end    -->
                                                        
                                                    </div>
                                                    <!-- Chatlist outer end  -->
                                                </div>
                                                <div class="_msgInnerWarp__right">
                                                    <div class="_chatBoxOuter">
                                                    		<div class="tab-content">
	
	<?php $__currentLoopData = $friends; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $friend): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

	<?php
		$profile = Auth::user()->userdetail->avatar;
	?>
         <?php if($loop->first): ?>
                <!-- Chat content begin  -->
        <listen-component :user-data="<?php echo e(json_encode([
	                                        'id' => Auth::id(),
	                                        'tab' => "{$friend->user->id}",
	                                        'name' => $friend->user->name,
	                                        'avatar' => asset("public/storage/{$friend->user->userdetail->avatar}"),
	                                        'active' => true,
	                                        'image' => asset("public/storage/{$profile}"),
                                            'url' => url("")

                                        ])); ?>">
        </listen-component>
        <?php else: ?>

        	  <listen-component :user-data="<?php echo e(json_encode([
	                                        'id' => Auth::id(),
	                                        'tab' => "{$friend->user->id}",
	                                        'name' => $friend->user->name,
	                                        'avatar' => asset("public/storage/{$friend->user->userdetail->avatar}"),
	                                        'active' => false,
	                                        'image' => asset("public/storage/{$profile}")
                                        ])); ?>">
        </listen-component>

        <?php endif; ?>

        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 



                                                        	

                                                            <!-- Chat content begin  --> 
                                                            
                                                        
                                                    </div>                                                       
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                    <!-- col end  -->
                                
                            </div>
                            <!-- row end  -->
                        </section>
                    </section>
                    <!--  dashboard body end   -->
                </div>
            </div>
            <!-- Dashboar left section end  -->
        </div>
        <!-- Row end  -->
    </div>
    <!-- Dashboard page inner end   -->
    </main>
</div>
<script>
	$(function(){

		$("#chat_lists li").click(function(){

			 $('li._chatList').removeClass('_newMsg');
   			 $(this).closest('li._chatList').addClass('_newMsg');
		});


	});

    function readMessage(sender_id,receiver_id) {
        $.post('<?php echo e(route('seller.message.read')); ?>', {_token: '<?php echo e(csrf_token()); ?>',sender_id:sender_id,receiver_id:receiver_id}, function(data, textStatus, xhr) {
            
        });
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/intlumin/public_html/hire/resources/views/seller/message/index.blade.php ENDPATH**/ ?>