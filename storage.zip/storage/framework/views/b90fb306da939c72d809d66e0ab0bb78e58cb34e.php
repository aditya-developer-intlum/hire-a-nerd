<?php echo e($slot); ?>

<?php /**PATH /home/intlumin/public_html/hire/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>