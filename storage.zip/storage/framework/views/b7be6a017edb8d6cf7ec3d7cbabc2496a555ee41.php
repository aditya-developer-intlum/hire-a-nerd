
	<?php echo e($mails->message); ?>

<?php /**PATH /var/www/html/hire-a-nerd/resources/views/email.blade.php ENDPATH**/ ?>