<table class="table table-striped- table-bordered table-hover table-checkable" id="kt_table_1">
										<thead>
											<tr>
												<th>S.NO</th>
												<th>Name</th>
												<th>Phone</th>
												<th>Email</th>
												<th>Package</th>
												<th>Price</th>
												<th width="13%">Status</th>
											</tr>
										</thead>
										<tbody>
										<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<tr>
												<td><?php echo e($key+1); ?></td>
												<td><?php echo e($order->user->name ??''); ?></td>
												<td><?php echo e($order->user->mobile_number ?? ''); ?></td>
												<td><?php echo e($order->user->email ?? ''); ?></td>
												<td><?php echo e(ucfirst($order->package) ?? ''); ?></td>
												<td><?php echo e($order->transaction->amount); ?></td>
												<td>
								<?php if($order->is_accepted == true && $order->is_completed == false): ?>

									<span class="kt-badge kt-badge--success kt-badge--dot"></span>
										&nbsp;
									<span class="kt-font-bold kt-font-success">Working ...</span>
								<?php elseif($order->is_accepted == true && $order->is_completed == true): ?>

									<span class="kt-badge kt-badge--brand kt-badge--dot"></span>
										&nbsp;
									<span class="kt-font-bold kt-font-brand">Complete</span>

								<?php elseif($order->is_accepted == false && $order->is_completed == false): ?>

									<span class="kt-badge kt-badge--dark kt-badge--dot"></span>
										&nbsp;
									<span class="kt-font-bold kt-font-dark">Pending</span>

								<?php endif; ?>

												</td>
											</tr>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										
												
									
										
										
											
										</tbody>
										
									
</table><?php /**PATH /home/intlumin/public_html/hire/resources/views/admin/gig-manage/buyers.blade.php ENDPATH**/ ?>