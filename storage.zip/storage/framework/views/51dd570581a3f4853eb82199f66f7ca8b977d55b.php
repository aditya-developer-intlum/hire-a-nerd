
	<?php echo e($mails->message); ?>

<?php /**PATH /home/intlumin/public_html/hire/resources/views/email.blade.php ENDPATH**/ ?>